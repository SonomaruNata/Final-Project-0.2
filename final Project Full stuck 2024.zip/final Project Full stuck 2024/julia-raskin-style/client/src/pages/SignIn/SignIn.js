import React, { useState } from 'react';
import axiosInstance from '../../axiosInstance';
 // Adjust if axiosInstance is in src/
import { useNavigate } from 'react-router-dom';
import './SignIn.css';

const SignIn = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axiosInstance.post('/server/routs/users', { email, password });
      const { username, role, token } = response.data;

      // Save user information and token to localStorage
      localStorage.setItem('user', JSON.stringify({ username, role }));
      localStorage.setItem('token', token);

      // Navigate to admin dashboard or homepage based on role
      if (role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/');
      }
    } catch (error) {
      console.error('Login failed:', error.response?.data?.message || 'Unexpected error');
      alert('Invalid login credentials');
    }
  };

  return (
    <div className="sign-in-container">
      <div className="sign-in-card">
        <h2>Sign In</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="email"
            placeholder="Email"
            className="form-input"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            className="form-input"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button type="submit" className="sign-in-button">Sign In</button>
        </form>
      </div>
    </div>
  );
};

export default SignIn;
